var http = require('http');
var fs = require('fs');
const { type } = require('os');

http.createServer((req,res) =>
{
res.writeHead(200, {'Content-type': 'text/html'});





}






)
